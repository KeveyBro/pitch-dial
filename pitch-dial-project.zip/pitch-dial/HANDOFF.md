# Pitch Dial: handoff

Pitch Dial is a single-page ear-training game. It plays a target tone, and the player matches it either by turning a tuning dial or by singing. Each round reports how far off the player was in **Hz**, as a **fraction of a tone** (for example "≈ 1/8 of a tone too high") and in **cents**.

It was inspired by matchthefreq.site. The player wanted the same game, plus the fraction-of-a-tone readout, plus a singing mode.

- Published version (claude.ai artifact, private to the owner): https://claude.ai/artifact/W3KBvDwk3fSpXqAKgEQw9E
- Live-microphone version: `dist/pitch-dial-mic.html`. Open it directly in Chrome or Edge.

## Files

| Path | What it is |
|---|---|
| `pitch-dial.html` | **The source of truth.** Written in claude.ai Artifact format, so it has no `<!doctype>`, `<html>`, `<head>` or `<body>`; the publisher adds those. All CSS and JS are inline. |
| `tools/build-standalone.js` | Wraps `pitch-dial.html` in a full HTML skeleton and writes `dist/pitch-dial-mic.html`. Run it after every change to the source. |
| `tools/test-pitch.js` | Headless tests for the scoring maths, YIN pitch detection, the held-note tracker and recording analysis, using synthetic voices. |
| `dist/pitch-dial-mic.html` | Built standalone file. Don't edit it by hand. |

```bash
node tools/test-pitch.js            # tests the source (or pass a path, e.g. dist/pitch-dial-mic.html)
node tools/build-standalone.js      # rebuilds dist/pitch-dial-mic.html
```

There's no package.json and there are no dependencies. Node 18+ is enough.

## Why there are two versions

Pages published inside claude.ai can't use the microphone. The viewer frame refuses `getUserMedia` without a prompt, and there's no runtime capability for it on this account. So:

- **The artifact** handles singing mode with a fallback: the player records the note in any voice-memo app and uploads it, and the page analyses the file offline. The "Hear the target again" button exists only in this fallback.
- **The standalone file** opened from disk gets live mic input. Chrome, Edge and Firefox allow `getUserMedia` on `file://` with a permission prompt. Safari is untested.

The page tries the mic when a singing game starts and switches to upload mode on its own if the mic is refused or the request times out after 20 seconds.

## How the code is organised (inside the single `<script>`)

The script sections are in this order and are marked with `/* ---------- name ---------- */` comments. `tools/test-pitch.js` extracts everything between the `maths` marker and the `audio out` marker, so keep those two markers and keep the pure functions between them.

1. **maths**: `centsBetween`, `round2`, `fractionText` (the "≈ 1/x of a tone" wording), `fractionShort`, `noteLabel`, `points`, `grade`, `describe`, `foldOctave`.
2. **pitch detection (YIN)**: `rms`, `yin(buf, sr)` (threshold 0.15, 60–1100 Hz, parabolic interpolation), `medianOf`, `makeTracker()`, `analyzeRecording(audioBuffer)`.
3. **audio out**: a shared `AudioContext` and master gain. `playTone` handles one-shot tones and `startTuner`/`setTunerFreq`/`stopTuner` handle the dial's continuous tone. Volume maps as `0.5 × v²`.
4. **microphone**: `openMic`/`closeMic`. Echo cancellation, noise suppression and AGC are turned off. The analyser is connected to a zero-gain sink so it keeps processing.
5. **canvas**: `readTokens` reads CSS colour tokens so the canvases follow the theme. `drawDial(canvas, freq, lo, hi, dim)` draws the amber dial at 1 px = 1 cent, with semitone ticks labelled with note name and Hz.
6. **game flow**: phases are `setup → listen → tune | sing → result → … → summary`. Each async step captures `flow` and stops if it has changed; anything that leaves a phase does `flow++`.
7. **input handlers** for the dial (drag, wheel, keys, coarse slider, hold-to-repeat nudge buttons), singing (live loop, upload, skip, best attempt) and the setup form.

### Scoring rules

- The target and the answer are both rounded to 0.01 Hz before comparing, so the Hz shown always matches the arithmetic.
- `cents = 1200 · log2(answer / reference)`. The fraction is `|cents| / unit`, where unit is 200 for a whole tone or 100 for a semitone. Below 0.6 of a unit it's shown as `1/round(unit/|cents|)`; at 0.6 or above it's shown as a decimal.
- Points per round: `round(100 · e^(−|cents|/60))`.
- Grades: under 5¢ Excellent, under 15¢ Very close, under 40¢ Close, under 100¢ Off, otherwise Way off.
- In singing mode with "Count the same note in any octave" on, the reference becomes `target · 2^k`, where `k = round(cents / 1200)`. Hz-off is measured against that octave-shifted reference.
- Missed or skipped rounds score 0 and are left out of the averages.

### Singing detection

- The live loop analyses a 2048-sample frame (4096 above 50 kHz) every 30 ms or more. A frame counts as voiced when its RMS is above 0.006 and YIN confidence is above 0.8.
- `makeTracker({hold: 1.2, win: 0.4, tol: 50})`: over a 0.4 s window, at least 70% of frames must be voiced, and at least 80% of the voiced frames must sit within ±50¢ of their median. Once that steadiness lasts 1.2 s, the note locks to the median of the frames in the held run. The ±50¢ tolerance is there so normal vibrato still counts as steady.
- `analyzeRecording` halves the sample rate when it's 32 kHz or more, analyses at most 30 s, uses a gate of 5% of the file's peak, and returns the longest steady run of at least 0.5 s.
- Verified only on synthetic signals: harmonic-rich voices from 98 to 523 Hz, ±30¢ vibrato, jitter, noise, an upward scoop into the note, and a slide (which correctly doesn't lock). **It has not been tested with a real microphone and a real voice yet.**

### Storage (localStorage, every access wrapped in try/catch)

- `pitchdial.settings`: answer mode, listen time, time limit, rounds, ranges, unit, octave fold and volume.
- `pitchdial.best` and `pitchdial.best.sing`: `{avgCents, rounds}`, the best average for each mode. A best is only recorded for games with at least 5 scored rounds.
- The artifact and the standalone file have different origins, so they keep separate settings and bests.

### Design

The page is meant to look like an instrument panel: quiet enamel greys, with the amber backlit tuning dial and its red needle as the only loud element. Archivo is used at 125% width for display text and at normal width for body text, and Azeret Mono is used for numbers. Every colour is a CSS token on `:root`, with dark values under `prefers-color-scheme: dark` and `[data-theme="dark"]`. When publishing as an artifact, keep the claude.ai rules: Google Fonts is the only external stylesheet host, everything else is inline, the side gutter uses `max(16px, env(safe-area-inset-*))`, and `alert`/`confirm`/`prompt` aren't available.

## Research benchmarks used in the app and chat

| Benchmark | Cents | ≈ Fraction of a whole tone | Source |
|---|---|---|---|
| Discrimination threshold at 1 kHz, best 5% of 918 adults | 6.2 | 1/32 | Sci Rep 2017 (doi 10.1038/s41598-017-16526-8) |
| Same, median of everyone | 14.5 | 1/14 | same |
| Same, people with formal music training / without | 12.9 / 19.5 | 1/16 / 1/10 | same |
| Same, worst 5% | 77.4 | about 2/5 | same |
| Non-musicians matching with a slider (target replayable) | 13 | 1/15 | Hutchins, Larrouy-Maestri & Peretz 2014 (doi 10.3758/s13414-014-0732-1) |
| Non-musicians matching by singing | 38 | 1/5 | same |
| Lab difference limens by frequency: 125 / 250 / 500 / 1000 Hz | 43–52 / 17–19 / 6–10 / ~6 | 1/5–1/4 / ~1/11 / 1/33–1/20 / 1/33 | arXiv 2307.00084, Table 1 |

Caveats to keep in mind: discrimination thresholds are not the same thing as matching errors; matching from memory, which is what Pitch Dial measures, adds error; and accuracy in cents gets much worse below about 250 Hz. The summary screen shows the 13¢ slider benchmark in dial mode and the 38¢ singing benchmark in singing mode.

## The player so far

First dial game (5 rounds, mostly low targets of 158–492 Hz): average miss **10.4 cents (≈ 1/19 of a tone)**, scoring 424 out of 500. Three of the five rounds were within 6¢. Four of the five misses were flat, which is worth watching as a possible bias.

## Ideas for next steps

1. Test singing mode with a real mic in Chrome, Edge, Firefox and Safari. Tune the RMS gate (0.006), the confidence cut-off (0.8) and the hold time (1.2 s) against real voices.
2. Add a sharp/flat bias stat to the summary, such as the mean signed cents and the count of high vs low misses.
3. Put the research benchmarks on the summary as markers on a scale, so the player sees where their average falls.
4. Split results by frequency band (below 250 Hz vs above), because low notes are harder.
5. Add a history across games (per-viewer localStorage) with a small trend chart.
6. Offer an optional sung-vowel or complex timbre for the target, since a pure sine is hard to sing back.
7. If the published artifact gains microphone access later, drop the upload fallback in favour of live input there too.
