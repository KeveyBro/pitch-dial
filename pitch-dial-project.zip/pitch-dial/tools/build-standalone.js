// Builds a standalone HTML file from pitch-dial.html so it can be opened directly in a browser,
// where the microphone works (the claude.ai artifact viewer blocks it).
//
// pitch-dial.html is written in claude.ai Artifact format: no <!doctype>, <html>, <head> or <body>,
// because the Artifact publisher wraps the page in its own skeleton. This script adds an
// equivalent skeleton and the same small CSS reset the publisher adds.
//
// Usage: node tools/build-standalone.js [input] [output]
//   defaults: pitch-dial.html -> dist/pitch-dial-mic.html
const fs = require('fs');
const path = require('path');

const input = process.argv[2] || 'pitch-dial.html';
const output = process.argv[3] || path.join('dist', 'pitch-dial-mic.html');
let body = fs.readFileSync(input, 'utf8');

// Hoist <title>, <meta> and <link> tags into <head>.
const headTags = [];
body = body.replace(/<title>[\s\S]*?<\/title>|<meta\b[^>]*>|<link\b[^>]*>/gi, (tag) => { headTags.push(tag); return ''; });

const reset = [
  ':root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}',
  'body{margin:0;font:14px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif}',
  'img{max-width:100%}',
  '[hidden]{display:none!important}'
].join('');

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
${headTags.join('\n')}
<style>${reset}</style>
</head>
<body>
${body.trim()}
</body>
</html>
`;

fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, html);
console.log(`Wrote ${output} (${(html.length / 1024).toFixed(1)} KB)`);
